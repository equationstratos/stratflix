# -*- coding: utf-8 -*-
import sys
import urllib.parse
import requests
import re
import hashlib
import time
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration & Sécurité ---
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
# URL de ton fichier de hashes sur GitHub
HASH_LIST_URL = "https://raw.githubusercontent.com/equationstratos/stratflix/main/hashes.txt"

def verifier_licence():
    """Vérifie la validité de la licence (SHA-256 + Expiration 1 an)"""
    license_hash = ADDON.getSetting('stratflix_license_hash')
    activation_date = ADDON.getSetting('stratflix_date')
    
    # 1. Vérification expiration (365 jours)
    if license_hash and activation_date:
        expiration_time = float(activation_date) + (365 * 24 * 3600)
        if time.time() < expiration_time:
            return True
        else:
            xbmcgui.Dialog().ok("Stratflix", "Votre licence a expiré (validité 1 an).")
            ADDON.setSetting('stratflix_license_hash', '')
    
    # 2. Demande de nouvelle clé
    kb = xbmcgui.Dialog().input("Entrez votre clé Stratflix (20 caractères)", type=xbmcgui.INPUT_ALPHANUM)
    if not kb or len(kb) != 20:
        xbmcgui.Dialog().ok("Erreur", "Clé invalide (20 caractères requis).")
        return False
        
    # 3. Hachage de la clé saisie
    saisie_hash = hashlib.sha256(kb.upper().encode()).hexdigest()
    
    # 4. Vérification distante
    try:
        xbmcgui.Dialog().notification("Sécurité", "Vérification en cours...", xbmcgui.NOTIFICATION_INFO, 2000)
        r = requests.get(HASH_LIST_URL, timeout=10)
        if saisie_hash in r.text.splitlines():
            ADDON.setSetting('stratflix_license_hash', saisie_hash)
            ADDON.setSetting('stratflix_date', str(time.time()))
            xbmcgui.Dialog().ok("Succès", "Accès activé pour 365 jours !")
            return True
        else:
            xbmcgui.Dialog().ok("Refusé", "Clé inconnue. Accès bloqué.")
            return False
    except:
        xbmcgui.Dialog().ok("Erreur", "Impossible de vérifier la clé (Pas d'internet ?)")
        return False

# --- Menus ---

def main_menu():
    add_item("[COLOR yellow]🔍 RECHERCHE[/COLOR]", "search", "")
    add_item("[COLOR white]🎬 FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/")
    add_item("[COLOR lightblue]📺 SÉRIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/")
    add_item("[COLOR orange]📂 GENRES[/COLOR]", "genres_menu", "")
    xbmcplugin.endOfDirectory(HANDLE)

# [ ... Le reste de tes fonctions : genres_menu, list_movies, etc. restent identiques ... ]

def add_item(name, action, url, thumb="", is_folder=True, plot=""):
    li = xbmcgui.ListItem(label=name)
    if thumb: li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': thumb})
    if plot:
        info = li.getVideoInfoTag()
        info.setPlot(plot)
    q = urllib.parse.urlencode({'action': action, 'url': url})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- Scraping ---
def get_html(url, post_data=None):
    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        r = requests.post(url, headers=headers, data=post_data, timeout=10) if post_data else requests.get(url, headers=headers, timeout=10)
        r.encoding = 'utf-8'
        return r.text
    except: return None

def fetch_synopsis(movie_url):
    html = get_html(movie_url)
    if not html: return ""
    soup = BeautifulSoup(html, 'html.parser')
    desc_block = soup.find('div', class_='screenshots-full')
    if desc_block:
        text = desc_block.get_text(" ", strip=True)
        if "Synopsis:" in text: return text.split("Synopsis:")[-1].strip()
    return "Cliquez pour voir les sources."

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    add_item("[COLOR cyan]🏠 RETOUR AU MENU PRINCIPAL[/COLOR]", "main", "")
    html = get_html(url, post_data)
    if not html: 
        xbmcplugin.endOfDirectory(HANDLE)
        return
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('div', class_='mov')
    if not post_data and len(items) > 42:
        items = items[30:-12]
    movie_list = []
    for item in items:
        link_tag = item.find('a', class_='mov-t')
        if link_tag:
            title = re.sub(r'(?i)flemmix|en streaming|vf|vostfr', '', link_tag.get_text(strip=True)).strip(' -:').strip()
            href = link_tag['href']
            img = item.find('img')
            thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
            movie_list.append({'title': title, 'url': href, 'thumb': thumb})
    with ThreadPoolExecutor(max_workers=10) as executor:
        synopses = list(executor.map(fetch_synopsis, [m['url'] for m in movie_list]))
    for i, m in enumerate(movie_list):
        li = xbmcgui.ListItem(label=m['title'])
        li.setArt({'thumb': m['thumb'], 'poster': m['thumb'], 'fanart': m['thumb']})
        info = li.getVideoInfoTag()
        info.setPlot(synopses[i])
        info.setMediaType('movie')
        q = urllib.parse.urlencode({'action': 'select_source', 'url': m['url'], 'title': m['title'], 'thumb': m['thumb']})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def select_source(url, title, thumb):
    html = get_html(url)
    if not html: return
    plot = fetch_synopsis(url)
    servers = {'voe.sx': 'VOE', 'christopheruntilpoint.com': 'VOE', 'uqload': 'UQLOAD', 'vidmoly': 'VIDMOLY', 'dsvplay': 'DDSTREAM', 'luluvdo': 'LULUTV', 'waaw': 'NETU', 'minochinos': 'FILELIONS'}
    matches = re.findall(r"loadVideo\('(.+?)'\)", html)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        srv_name = "SOURCE"
        for key, name in servers.items():
            if key in v_url.lower(): srv_name = name; break
        li = xbmcgui.ListItem(label=f"▶ {srv_name}")
        li.setArt({'thumb': thumb, 'poster': thumb})
        li.setProperty('IsPlayable', 'true')
        info = li.getVideoInfoTag()
        info.setPlot(plot)
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Recherche')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", data)

# --- Router ---
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
action = params.get('action')

if not action or action == 'main':
    # ON LANCE LA VÉRIFICATION AU TOUT DÉBUT
    if verifier_licence():
        main_menu()
elif action == 'genres_menu':
    if verifier_licence(): genres_menu()
elif action == 'list_movies':
    list_movies(params.get('url'))
elif action == 'select_source':
    select_source(params.get('url'), params.get('title'), params.get('thumb'))
elif action == 'play':
    play_video(params.get('url'))
elif action == 'search':
    search()
