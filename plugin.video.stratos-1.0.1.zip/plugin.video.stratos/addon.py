# -*- coding: utf-8 -*-
import sys
import urllib.parse
import requests
import re
import hashlib
import time
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration & Sécurité ---
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

# URL de ton fichier de hashes sur GitHub (Vérifie bien que ce lien est valide)
HASH_LIST_URL = "https://raw.githubusercontent.com/equationstratos/stratflix/main/hashes.txt"

def verifier_licence():
    """Vérifie la validité de la licence (SHA-256 + Expiration 1 an)"""
    # Récupération des données locales
    license_hash = ADDON.getSetting('stratflix_license_hash')
    activation_date = ADDON.getSetting('stratflix_date')
    
    # 1. Si déjà activé, on vérifie la date d'expiration
    if license_hash and activation_date:
        try:
            expiration_time = float(activation_date) + (365 * 24 * 3600)
            if time.time() < expiration_time:
                return True
            else:
                xbmcgui.Dialog().ok("Stratflix", "Votre licence a expiré (validité 1 an).")
                ADDON.setSetting('stratflix_license_hash', '')
        except: 
            pass # Erreur de conversion, on redemande la clé
    
    # 2. Si pas de licence valide, on demande la saisie de la clé de 20 caractères
    dialog = xbmcgui.Dialog()
    kb = dialog.input("Activation Stratflix (Clé de 20 caractères)", type=xbmcgui.INPUT_ALPHANUM)
    
    if not kb or len(kb) != 20:
        dialog.ok("Erreur", "Format de clé invalide (20 caractères requis).")
        return False
        
    # 3. Hachage de la clé (en majuscules pour éviter les erreurs de frappe)
    saisie_hash = hashlib.sha256(kb.upper().encode()).hexdigest()
    
    # 4. Vérification sur ton GitHub
    try:
        dialog.notification("Sécurité", "Vérification en cours...", xbmcgui.NOTIFICATION_INFO, 2000)
        r = requests.get(HASH_LIST_URL, timeout=10)
        
        if r.status_code == 200:
            liste_valide = [h.strip().lower() for h in r.text.splitlines() if h.strip()]
            
            if saisie_hash.lower() in liste_valide:
                # Sauvegarde immédiate
                ADDON.setSetting('stratflix_license_hash', saisie_hash)
                ADDON.setSetting('stratflix_date', str(time.time()))
                dialog.ok("Félicitations", "Accès Stratflix activé pour 365 jours !")
                return True
            else:
                dialog.ok("Refusé", "Cette clé n'est pas dans notre base de données.")
                return False
        else:
            dialog.ok("Erreur Serveur", "Impossible de lire la liste des clés sur GitHub (Erreur 404/500).")
            return False
            
    except Exception as e:
        dialog.ok("Erreur Réseau", "Vérifiez votre connexion internet.")
        return False

# --- Menus ---

def main_menu():
    add_item("[COLOR yellow]🔍 RECHERCHE[/COLOR]", "search", "")
    add_item("[COLOR white]🎬 FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/")
    add_item("[COLOR lightblue]📺 SÉRIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/")
    add_item("[COLOR orange]📂 GENRES[/COLOR]", "genres_menu", "")
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    add_item("[COLOR cyan]🏠 RETOUR AU MENU PRINCIPAL[/COLOR]", "main", "")
    genres = [
        ("🎭 Action", "/film-en-streaming/action/"), ("💥 Animation", "/film-en-streaming/animation/"),
        ("🥋 Arts Martiaux", "/film-en-streaming/arts-martiaux/"), ("🧗 Aventure", "/film-en-streaming/aventure/"),
        ("📜 Biopic", "/film-en-streaming/biopic/"), ("😂 Comédie", "/film-en-streaming/comedie/"),
        ("🧛 Horreur", "/film-en-streaming/epouvante-horreur/"), ("🏛️ Drame", "/film-en-streaming/drame/"),
        ("🪄 Fantastique", "/film-en-streaming/fantastique/"), ("🚔 Policier", "/film-en-streaming/policier/"),
        ("🚀 Science Fiction", "/film-en-streaming/science-fiction/"), ("🕵️ Thriller", "/film-en-streaming/thriller/")
    ]
    for name, path in genres:
        add_item(name, "list_movies", BASE_URL + path)
    xbmcplugin.endOfDirectory(HANDLE)

def add_item(name, action, url, thumb="", is_folder=True, plot=""):
    li = xbmcgui.ListItem(label=name)
    if thumb: li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': thumb})
    if plot:
        info = li.getVideoInfoTag()
        info.setPlot(plot)
    q = urllib.parse.urlencode({'action': action, 'url': url})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- Scraping ---

def get_html(url, post_data=None):
    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        r = requests.post(url, headers=headers, data=post_data, timeout=10) if post_data else requests.get(url, headers=headers, timeout=10)
        r.encoding = 'utf-8'
        return r.text
    except: return None

def fetch_synopsis(movie_url):
    html = get_html(movie_url)
    if not html: return ""
    soup = BeautifulSoup(html, 'html.parser')
    desc_block = soup.find('div', class_='screenshots-full')
    if desc_block:
        text = desc_block.get_text(" ", strip=True)
        if "Synopsis:" in text: return text.split("Synopsis:")[-1].strip()
    return "Cliquez pour voir les sources."

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    add_item("[COLOR cyan]🏠 RETOUR AU MENU PRINCIPAL[/COLOR]", "main", "")
    html = get_html(url, post_data)
    if not html: 
        xbmcplugin.endOfDirectory(HANDLE)
        return
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('div', class_='mov')
    if not post_data and len(items) > 42:
        items = items[30:-12]
    movie_list = []
    for item in items:
        link_tag = item.find('a', class_='mov-t')
        if link_tag:
            title = re.sub(r'(?i)flemmix|en streaming|vf|vostfr', '', link_tag.get_text(strip=True)).strip(' -:').strip()
            href = link_tag['href']
            img = item.find('img')
            thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
            movie_list.append({'title': title, 'url': href, 'thumb': thumb})
    with ThreadPoolExecutor(max_workers=10) as executor:
        synopses = list(executor.map(fetch_synopsis, [m['url'] for m in movie_list]))
    for i, m in enumerate(movie_list):
        li = xbmcgui.ListItem(label=m['title'])
        li.setArt({'thumb': m['thumb'], 'poster': m['thumb'], 'fanart': m['thumb']})
        info = li.getVideoInfoTag()
        info.setPlot(synopses[i])
        info.setMediaType('movie')
        q = urllib.parse.urlencode({'action': 'select_source', 'url': m['url'], 'title': m['title'], 'thumb': m['thumb']})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def select_source(url, title, thumb):
    html = get_html(url)
    if not html: return
    plot = fetch_synopsis(url)
    servers = {'voe.sx': 'VOE', 'uqload': 'UQLOAD', 'vidmoly': 'VIDMOLY', 'waaw': 'NETU'}
    matches = re.findall(r"loadVideo\('(.+?)'\)", html)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        srv_name = "SOURCE"
        for key, name in servers.items():
            if key in v_url.lower(): srv_name = name; break
        li = xbmcgui.ListItem(label=f"▶ {srv_name}")
        li.setArt({'thumb': thumb, 'poster': thumb})
        li.setProperty('IsPlayable', 'true')
        info = li.getVideoInfoTag()
        info.setPlot(plot)
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Recherche')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", data)

# --- Router ---
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
action = params.get('action')

# BLOCAGE TOTAL TANT QUE LA LICENCE N'EST PAS VALIDE
if verifier_licence():
    if not action or action == 'main': main_menu()
    elif action == 'genres_menu': genres_menu()
    elif action == 'list_movies': list_movies(params.get('url'))
    elif action == 'select_source': select_source(params.get('url'), params.get('title'), params.get('thumb'))
    elif action == 'play': play_video(params.get('url'))
    elif action == 'search': search()
